package com.hansung.android.smart_parking;


import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;


/**
 * Created by user on 2017-07-26.
 */
public class loadMysql extends Thread {

    public static boolean active=false;
    Handler mHandler;
    String url=null;


    public loadMysql(){ //이미지 추가
        url="http://"+Data.IP_ADDRESS+"/loadImage.php";
        mHandler= new Handler(Looper.getMainLooper());
        Log.e("url",url);
    }

    @Override
    public void run() {
        super.run();
        if(active){

            StringBuilder sb = new StringBuilder();
        try {
            URL phpUrl = new URL(url);

            HttpURLConnection httpURLConnection = (HttpURLConnection)phpUrl.openConnection();

            if ( httpURLConnection != null ) {
                httpURLConnection.setConnectTimeout(10000);
                httpURLConnection.setUseCaches(false);
                httpURLConnection.setRequestProperty("Content-Length", Integer.toString(url.length()));

                if ( httpURLConnection.getResponseCode() == HttpURLConnection.HTTP_OK ) {
                    BufferedReader br = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream(), "UTF-8"));
                    while ( true ) {
                        String line = br.readLine();
                        if ( line == null )
                            break;
                        sb.append(line + "\n");
                    }
                    br.close();
                }
                httpURLConnection.disconnect();
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        show(sb.toString());
    }



    }

    void show(final String result){
        mHandler.post(new Runnable(){

            @Override
            public void run() {
                ViewActivity.load_image(result);

            }
        });

    }


}
