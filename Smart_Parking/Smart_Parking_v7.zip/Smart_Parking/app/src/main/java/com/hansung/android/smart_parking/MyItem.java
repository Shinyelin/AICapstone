package com.hansung.android.smart_parking;

import android.graphics.drawable.Drawable;

class MyItem {
    private Drawable icon;
    private String name;
    private String car_number;
    private String contents; //등록여부

    public Drawable getIcon() {
        return icon;
    }

    public void setIcon(Drawable icon) {
        this.icon = icon;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public String getCarNumber() {
        return car_number;
    }

    public void setCarNumber(String carnumber) {
        this.car_number = carnumber;
    }

    public String getContents() {
        return contents;
    }

    public void setContents(String contents) {
        this.contents = contents;
    }
}
