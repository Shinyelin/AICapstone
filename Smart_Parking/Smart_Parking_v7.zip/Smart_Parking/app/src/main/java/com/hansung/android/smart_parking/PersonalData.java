package com.hansung.android.smart_parking;

import android.app.Activity;

public class PersonalData {
    private String member_cnum;
    private String member_cowner;
    private String member_cphone;

    public String getMember_cnum() {
        return member_cnum;
    }

    public String getMember_cowner() {
        return member_cowner;
    }

    public String getMember_cphone() {
        return member_cphone;
    }

    public void setMember_cnum(String member_cnum) {
        this.member_cnum = member_cnum;
    }

    public void setMember_cowner(String member_cowner) {
        this.member_cowner = member_cowner;
    }

    public void setMember_cphone(String member_cphone) {
        this.member_cphone = member_cphone;
    }
}