package com.hansung.android.smart_parking;

import android.app.Application;

public class Data  extends Application {
    private String _carparkname;
    private String _carparkaddress;
    static String IP_ADDRESS= "172.30.1.46";
    static String aPlot= "";
    static String aAddress= "";
    static int cnt_P= 1;
    static int cnt_D= 1;

    public String getCarParkName() {   return _carparkname;  }
    public String getCarParkAddress() {   return _carparkaddress;  }

}
