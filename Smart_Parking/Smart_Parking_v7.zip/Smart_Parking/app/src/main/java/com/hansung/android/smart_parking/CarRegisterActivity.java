package com.hansung.android.smart_parking;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.renderscript.ScriptGroup;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpCookie;
import java.net.HttpURLConnection;
import java.net.URL;

public class CarRegisterActivity extends AppCompatActivity {
    //private static String IP_ADDRESS = "172.30.1.6";
    private static String TAG = "car";
    EditText et_cnum, et_cowner,et_cphone;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_register);

        et_cnum=(EditText)findViewById(R.id.et_cnum);
        et_cowner=(EditText)findViewById(R.id.et_cowner);
        et_cphone=(EditText)findViewById(R.id.et_cphone);

        final Button parkingplacebtn = (Button)findViewById(R.id.btn_parkingplace);
        parkingplacebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String[] ParkingPlace = new String[]{"장애인","임산부"};
                final int[] selectedIndex={0};

                AlertDialog.Builder parkingplace_dialog = new AlertDialog.Builder(CarRegisterActivity.this);
                parkingplace_dialog.setTitle("해당 사항을 선택하세요")
                        .setSingleChoiceItems(ParkingPlace
                                , 0
                                , new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        selectedIndex[0] = which;
                                    }
                                })
                        .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(CarRegisterActivity.this, ParkingPlace[selectedIndex[0]],
                                        Toast.LENGTH_LONG).show();
                                parkingplacebtn.setText(ParkingPlace[selectedIndex[0]]);

                            }
                        }).create().show();

            }
        });
    }

    public void car_register_submitClick(View view){

        InsertData task = new InsertData();
        task.execute("http://"+Data.IP_ADDRESS+"/insert_car.php",et_cnum.getText().toString(), et_cowner.getText().toString(),et_cphone.getText().toString());
        Intent intent = new Intent(this,CarInfoActivity.class);
        finish();
        startActivity(intent);
    }
    class InsertData extends AsyncTask<String, Void, String>{
        ProgressDialog progressDialog;

        @Override
        protected void  onPreExecute(){
            super.onPreExecute();

            progressDialog = ProgressDialog.show(CarRegisterActivity.this,"Wait...",null,true,true);
        }

        @Override
        protected void onPostExecute(String result){
            super.onPostExecute(result);

            progressDialog.dismiss();
            //mTextViewResult.setText(result);
            Log.d(TAG,"Post response -"+result);
        }

        @Override
        protected String doInBackground(String... params){
            String cnum = (String)params[1];
            String cowner = (String)params[2];
            String cphone = (String)params[3];

            String serverURL = (String)params[0];
            String postParameters = "cnum="+cnum+"&cowner="+cowner+"&cphone="+cphone;

            try{
                URL url = new URL(serverURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();

                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.connect();

                OutputStream outputStream = httpURLConnection.getOutputStream();
                outputStream.write(postParameters.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();

                int responseStatusCode = httpURLConnection.getResponseCode();
                Log.d(TAG, "POST response code - "+responseStatusCode);

                InputStream inputStream;
                if(responseStatusCode==HttpURLConnection.HTTP_OK){
                    inputStream = httpURLConnection.getInputStream();
                }
                else{
                    inputStream = httpURLConnection.getErrorStream();
                }
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream,"UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                StringBuilder sb = new StringBuilder();
                String line = null;

                while ((line=bufferedReader.readLine())!=null){
                    sb.append(line);
                }

                bufferedReader.close();

                return  sb.toString();


            }catch (Exception e){
                Log.d(TAG,"InsertData : Error", e);
                return new String("Error: "+e.getMessage());
            }
        }
    }

}

