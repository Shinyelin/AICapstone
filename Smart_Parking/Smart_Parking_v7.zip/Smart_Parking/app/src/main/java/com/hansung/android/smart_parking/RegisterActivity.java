package com.hansung.android.smart_parking;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class RegisterActivity extends AppCompatActivity {
    //private static String IP_ADDRESS = "172.30.1.6";
    private static String TAG = "admin";
    String aplot="";
    EditText et_aid, et_apwd, getEt_aid_confirm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        et_aid = (EditText)findViewById(R.id.et_aid);
        et_apwd = (EditText)findViewById(R.id.et_apwd);

        final Button workplacebtn = (Button)findViewById(R.id.btn_aplot);
        workplacebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String[] WorkPlace = new String[]{"han","한성대학교 주차장","신촌 현대백화점 주차장","올림픽공원 주차장"
                        ,"창천프라자 주차장","세학 민영 주차장"};
                final int[] selectedIndex={0};

                AlertDialog.Builder maindialog = new AlertDialog.Builder(RegisterActivity.this);
                maindialog.setTitle("근무장소를 선택하세요")
                        .setSingleChoiceItems(WorkPlace
                                , 0
                                , new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        selectedIndex[0] = which;
                                    }
                                })
                        .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(RegisterActivity.this, WorkPlace[selectedIndex[0]],
                                        Toast.LENGTH_LONG).show();
                                workplacebtn.setText(WorkPlace[selectedIndex[0]]);
                                aplot =WorkPlace[selectedIndex[0]];

                            }
                        }).create().show();

            }
        });
    }

    public void register_submitClick(View view){


        RegisterActivity.InsertData_admin task = new RegisterActivity.InsertData_admin();
        task.execute("http://"+Data.IP_ADDRESS+"/insert_admin.php",et_aid.getText().toString(),et_apwd.getText().toString(),aplot);
        Intent intent1 = new Intent(this,LoginActivity.class);
        startActivity(intent1);
    }
    public void onClick_addplace(View view){
        Intent intent1 = new Intent(this,AddPlaceActivity.class);
        startActivity(intent1);
    }
    class InsertData_admin extends AsyncTask<String, Void, String> {
        ProgressDialog progressDialog;

        @Override
        protected void  onPreExecute(){
            super.onPreExecute();

            progressDialog = ProgressDialog.show(RegisterActivity.this,"Wait...",null,true,true);
        }

        @Override
        protected void onPostExecute(String result){
            super.onPostExecute(result);

            progressDialog.dismiss();
            //mTextViewResult.setText(result);
            Log.d(TAG,"Post response -"+result);
        }

        @Override
        protected String doInBackground(String... params){
            String aId = (String)params[1];
            String aPwd = (String)params[2];
            String aPlot = (String)params[3];

            String serverURL = (String)params[0];
            String postParameters = "aId="+aId+"&aPwd="+aPwd+"&aPlot="+aPlot;

            try{
                URL url = new URL(serverURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();

                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.connect();

                OutputStream outputStream = httpURLConnection.getOutputStream();
                outputStream.write(postParameters.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();

                int responseStatusCode = httpURLConnection.getResponseCode();
                Log.d(TAG, "POST response code - "+responseStatusCode);

                InputStream inputStream;
                if(responseStatusCode==HttpURLConnection.HTTP_OK){
                    inputStream = httpURLConnection.getInputStream();
                }
                else{
                    inputStream = httpURLConnection.getErrorStream();
                }
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream,"UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                StringBuilder sb = new StringBuilder();
                String line = null;

                while ((line=bufferedReader.readLine())!=null){
                    sb.append(line);
                }

                bufferedReader.close();

                return  sb.toString();


            }catch (Exception e){
                Log.d(TAG,"InsertData : Error", e);
                return new String("Error: "+e.getMessage());
            }
        }
    }

}
