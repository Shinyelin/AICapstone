package com.hansung.android.smart_parking;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class View2Activity extends AppCompatActivity {
    static final int getimagesetting=1001;//for request intent
    static Context mContext;
    static String  result_time,result_extract;
    static  String result_piname,result_piip;
    String temp="";
    Bitmap data;
    String mJsonString = "";
    static ImageView IV_piimg;
    Drawable refresh;
    private static String TAG = "ImageRoad";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);
        Intent resultintent =getIntent();
        result_piip =resultintent.getExtras().getString("PIID","아이디");
        result_piname =resultintent.getExtras().getString("PINAME","이름");
        result_time =resultintent.getExtras().getString("PITIME","시간");
        result_extract =resultintent.getExtras().getString("PIEXTRACT","추출");
        TextView TV_piextract =(TextView)findViewById(R.id.tv_piextract);
        TV_piextract.setText(result_extract);
        TextView TV_pitime =(TextView)findViewById(R.id.tv_pitime);
        TV_pitime.setText(result_time);
        IV_piimg =(ImageView)findViewById(R.id.iv_picam);
        IV_piimg.setImageResource(R.drawable.refresh);//썸네일
        //IV_piimg.setImageBitmap(data);
        //loadMysql getting=new loadMysql();
        //loadMysql.active=true;
        //getting.start();
        View2Activity.GetData task = new View2Activity.GetData();
        task.execute(result_piip);
    }
    public void onClick_view_ok(View view){
        Intent intent1 = new Intent(this,MainActivity.class);
        finish();
        startActivity(intent1);

    }public void onClick_view_notok(View view){
        Intent intent = new Intent(this,NumberModifyActivity.class);
        finish();
        startActivity(intent);
    }
    private class GetData extends AsyncTask<String, Void, String> {
        String errorString = null;

        @Override
        protected void onPreExecute() {

            super.onPreExecute();


        }


        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);



            Log.d(TAG, "response - " + result);

            if (result == null) {

                Toast.makeText(View2Activity.this, errorString,
                        Toast.LENGTH_SHORT).show();
            }

            else {

                mJsonString = result;

                showResult();

                //dataSetting();


            }
        }


        @Override
        protected String doInBackground(String... params) {

            String searchKeyword1 = params[0];
            //String searchKeyword2 = params[1];



            String serverURL = "http://"+Data.IP_ADDRESS+"/loadImage.php";
            String postParameters = "id=" + searchKeyword1;


            try {

                StringBuilder sb = new StringBuilder();

                URL url = new URL(serverURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();


                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoInput(true);
                httpURLConnection.connect();


                OutputStream outputStream = httpURLConnection.getOutputStream();
                outputStream.write(postParameters.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();


                int responseStatusCode = httpURLConnection.getResponseCode();
                //Log.d(TAG, "response code - " + responseStatusCode);
                if ( httpURLConnection.getResponseCode() == HttpURLConnection.HTTP_OK ) {
                    BufferedReader br = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream(), "UTF-8"));
                    while ( true ) {
                        String line = br.readLine();
                        if ( line == null )
                            break;
                        sb.append(line + "\n");
                    }
                    br.close();
                }
/*
                InputStream inputStream;
                if (responseStatusCode == HttpURLConnection.HTTP_OK) {
                    inputStream = httpURLConnection.getInputStream();
                } else {
                    inputStream = httpURLConnection.getErrorStream();
                }


                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                StringBuilder sb = new StringBuilder();
                String line;
                while(true){
                    line = bufferedReader.readLine();
                    if(line==null)
                        break;
                    sb.append(line+"\n");
                }


                sb.close();*/


                //return sb.toString().trim();
                return sb.toString().trim();



            } catch (Exception e) {

                //Log.d(TAG, "InsertData: Error ", e);
                errorString = e.toString();

                return null;
            }

        }
    }
    private void showResult(){

        String TAG_JSON="webnautes";
        //String TAG_PIID = "id";



        try {
            /*
            JSONObject jsonObject = new JSONObject(mJsonString);
            JSONArray jsonArray = jsonObject.getJSONArray(TAG_JSON);

            JSONObject item = jsonArray.getJSONObject(0);

              data=StringToBitMap(item.getString("piImg"));
              Log.e("load_image",item.get("piImg").toString());
              IV_piimg.setImageBitmap(data);//썸네일*/
            JSONArray jArray=new JSONArray(mJsonString);

            //list_cnt=jArray.length();
            //Log.e("array_count try",list_cnt+"");
            // getNo=new String[list_cnt];
            // getBlob=new Bitmap[list_cnt];

            JSONObject jsonObject=jArray.getJSONObject(0);
            //getNo[i]=jsonObject.getString("id");
            data=StringToBitMap(jsonObject.getString("piImg"));
            Log.e("load_image",jsonObject.get("piImg").toString());
            IV_piimg.setImageBitmap(data);


        } catch (JSONException e) {

            Log.d(TAG, "showResult : ", e);
        }

    }


    /**
     * string을 bitmap으로
     * @param image
     */
    public static Bitmap StringToBitMap(String image){
        Log.e("StringToBitMap","StringToBitMap");
        try{
            byte [] encodeByte=Base64.decode(image,Base64.DEFAULT);
            Bitmap bitmap= BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.length);
            Log.e("StringToBitMap","good");

            return bitmap;
        }catch(Exception e){
            e.getMessage();
            return null;
        }
    }

}
