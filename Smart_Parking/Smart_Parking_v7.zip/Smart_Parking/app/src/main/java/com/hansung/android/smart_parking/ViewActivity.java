package com.hansung.android.smart_parking;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.net.URLEncoder;

public class ViewActivity extends AppCompatActivity {
    static final int getimagesetting=1001;//for request intent
    static Context mContext;
    static String  result_time,result_extract;
    static  String result_piname,result_piip;
    String temp="";
    Bitmap data;
    static ImageView IV_piimg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);
        Intent resultintent =getIntent();
        result_piip =resultintent.getExtras().getString("PIID","아이디");
        result_piname =resultintent.getExtras().getString("PINAME","이름");
        result_time =resultintent.getExtras().getString("PITIME","시간");
        result_extract =resultintent.getExtras().getString("PIEXTRACT","추출");
        TextView TV_piextract =(TextView)findViewById(R.id.tv_piextract);
        TV_piextract.setText(result_extract);
        TextView TV_pitime =(TextView)findViewById(R.id.tv_pitime);
        TV_pitime.setText(result_time);
        IV_piimg =(ImageView)findViewById(R.id.iv_picam);
        //IV_piimg.setImageBitmap(data);
        loadMysql getting=new loadMysql();
        loadMysql.active=true;
        getting.start();
    }
    public void onClick_view_ok(View view){
        Intent intent1 = new Intent(this,MainActivity.class);
        finish();
        startActivity(intent1);

    }public void onClick_view_notok(View view){
        Intent intent = new Intent(this,NumberModifyActivity.class);
        finish();
        startActivity(intent);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==getimagesetting){	//if image change

            if(resultCode==RESULT_OK){
                //Bitmap selPhoto = null;
                //selPhoto=(Bitmap) data.getParcelableExtra("bitmap");
                //IV_piimg.setImageBitmap(selPhoto);//썸네일
                //BitMapToString(selPhoto);

            }
        }
    }
    /**
     * bitmap을 string으로
     * @param bitmap
     */
    public void BitMapToString(Bitmap bitmap){

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG,100, baos);	//bitmap compress
        byte [] arr=baos.toByteArray();
        String image= Base64.encodeToString(arr, Base64.DEFAULT);


        try{
            temp="&imagedevice="+ URLEncoder.encode(image,"utf-8");
        }catch (Exception e){
            Log.e("exception",e.toString());
        }

    }

    /**
     * string을 bitmap으로
     * @param image
     */
    public static Bitmap StringToBitMap(String image){
        Log.e("StringToBitMap","StringToBitMap");
        try{
            byte [] encodeByte=Base64.decode(image,Base64.DEFAULT);
            Bitmap bitmap= BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.length);
            Log.e("StringToBitMap","good");
            return bitmap;
        }catch(Exception e){
            e.getMessage();
            return null;
        }
    }

    static public void load_image(String result){
        if(result.contains("false")){
            //Toast.makeText(mContext, "이미지를 가져오지 못했습니다.", Toast.LENGTH_SHORT).show();
        }else{
            Bitmap data;
            //String[] getNo;
            try{
                JSONArray jArray=new JSONArray(result);

                //list_cnt=jArray.length();
                //Log.e("array_count try",list_cnt+"");
               // getNo=new String[list_cnt];
               // getBlob=new Bitmap[list_cnt];

                JSONObject jsonObject=jArray.getJSONObject(0);
                    //getNo[i]=jsonObject.getString("id");
                data=StringToBitMap(jsonObject.getString("piImg"));
                 Log.e("load_image",jsonObject.get("piImg").toString());
                IV_piimg.setImageBitmap(data);//썸네일

                //list.setNo(getNo);

                //list.setBlob(getBlob);
                //list.notifyDataSetChanged();
            }catch (Exception e){

                String temp=e.toString();

                while (temp.length() > 0) {
                    if (temp.length() > 4000) {
                        Log.e("imageLog", temp.substring(0, 4000));
                        temp = temp.substring(4000);
                    } else {
                        Log.e("imageLog",  temp);
                        break;
                    }
                }
            }

        }
    }
}
