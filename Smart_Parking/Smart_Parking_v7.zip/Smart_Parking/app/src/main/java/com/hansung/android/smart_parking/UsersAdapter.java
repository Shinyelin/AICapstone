package com.hansung.android.smart_parking;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class UsersAdapter extends BaseAdapter {

    private ArrayList<PersonalData> mInfoList = new ArrayList<>();
    private Activity context = null;

    public UsersAdapter(Activity context, ArrayList<PersonalData> list) {
        this.context = context;
        this.mInfoList = list;
    }
    @Override
    public int getCount() {
        return mInfoList.size();
    }

    @Override
    public PersonalData getItem(int position) {
        return mInfoList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        Context context = parent.getContext();

        /* 'listview_d' Layout을 inflate하여 convertView 참조 획득 */
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.item_list, parent, false);
        }

        /* 'listview_d'에 정의된 위젯에 대한 참조 획득 */
        TextView tv_cnum = (TextView) convertView.findViewById(R.id.textview_list_cnum) ;
        TextView tv_cowner = (TextView) convertView.findViewById(R.id.textview_list_cowner) ;
        TextView tv_cphone = (TextView) convertView.findViewById(R.id.textview_list_cphone) ;

        /* 각 리스트에 뿌려줄 아이템을 받아오는데 mMyItem 재활용 */
        PersonalData myItem = getItem(position);

        /* 각 위젯에 세팅된 아이템을 뿌려준다 */
        tv_cnum.setText(myItem.getMember_cnum());
        tv_cowner.setText(myItem.getMember_cowner());
        tv_cphone.setText(myItem.getMember_cphone());


        return convertView;
    }

    /* 아이템 데이터 추가를 위한 함수. 자신이 원하는대로 작성 */
    public void addItem(String cnum, String cowner, String cphone) {

        PersonalData mInfolist = new PersonalData();

        /* MyItem에 아이템을 setting한다. */
        mInfolist.setMember_cnum(cnum);
        mInfolist.setMember_cowner(cowner);
        mInfolist.setMember_cphone(cphone);

        /* mItems에 MyItem을 추가한다. */
        mInfoList.add(mInfolist);

    }
}
