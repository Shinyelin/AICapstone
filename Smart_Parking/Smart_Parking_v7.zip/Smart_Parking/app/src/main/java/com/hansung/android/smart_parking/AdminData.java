package com.hansung.android.smart_parking;

public class AdminData {
}
